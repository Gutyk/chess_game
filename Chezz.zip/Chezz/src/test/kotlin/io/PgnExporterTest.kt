package io

import io.kotest.core.spec.style.StringSpec

/**
 * @author Dominik Hoftych
 */
class PgnExporterTest : StringSpec({
})
