package ui.views

import tornadofx.View
import tornadofx.vbox

/**
 * Timer view to the right of the chess board
 *
 * @author Dominik Hoftych
 */
class TimerView : View() {
    override val root = vbox {
        // TODO
    }
}
