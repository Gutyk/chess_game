package ui.fragments

import game.GameResult
import game.WinType
import javafx.application.Platform
import javafx.geometry.Pos
import javafx.scene.Parent
import javafx.scene.layout.Pane
import javafx.scene.text.FontWeight
import tornadofx.*
import ui.controllers.BoardController

/**
 * Dialog window that pops up when the game ends
 *
 * @author Dominik Hoftych
 */
class GameOverDialog : Fragment("Fim de Jogo") {

    /**
     * The result of the game
     */
    val gameResult: GameResult by param()

    /**
     * Reference to board controller in which the button actions are handled
     */
    private val boardController: BoardController by inject()

    override val root: Parent = gridpane {
        row { resultText(this) }
        row { buttons(this) }
    }

    /**
     * Displays text with the result of the game in the given [pane]
     */
    private fun resultText(pane: Pane) {
        pane.label(
            """
            O Jogo Terminou.. ${when (val result = gameResult) {
                is GameResult.BlackWins -> {
                    "Peões PRETOS venceram ${if (result.type == WinType.CHECKMATE) "por xeque-mate" else "no tempo"}!"
                }
                is GameResult.WhiteWins -> {
                    "Peões AZUILS venceram ${if (result.type == WinType.CHECKMATE) "por xeque-mate" else "no tempo"}!"
                }
                is GameResult.Draw -> {
                    "Empate por ${result.type}"
                }
                GameResult.StillPlaying -> throw IllegalArgumentException("O resultado deve ser conhecido neste momento")
            }}
            """.trimIndent()
        ) {
            style {
                fontWeight = FontWeight.BOLD
                alignment = Pos.CENTER
                paddingAll = 10
            }
        }
    }

    /**
     * Adds "menu" buttons to the given [pane]
     */
    private fun buttons(pane: Pane) {
        pane.hbox(spacing = 5) {
            button("Jogar Mais Uma").action {
                boardController.startGame()
                close()
            }
            button("Salvar Jogo").action {
                find<SaveGameDialog>(
                    SaveGameDialog::movetext to boardController.exportPgn(),
                    SaveGameDialog::result to boardController.getGameResult()
                ).openModal(resizable = false)
                close()
            }
            button("CConvença-se").action { close() }
            button("Ganhe vida e desista").action { Platform.exit() }
            style {
                alignment = Pos.CENTER
                paddingAll = 10
            }
        }
    }
}
